select min(s_acctbal), max(s_acctbal)
from supplier;
